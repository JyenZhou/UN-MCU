# LTC2946
This is a LTC2946 setup program, made by LTC for their power monitor test board.
